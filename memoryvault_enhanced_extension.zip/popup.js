const search = document.getElementById("search");
const results = document.getElementById("results");

function findMatches(pages, query) {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  const words = q.split(/\s+/);
  return pages.filter(p => {
    const text = (p.title + " " + p.url + " " + p.content).toLowerCase();
    return words.every(w => text.includes(w));
  });
}

function highlightSnippet(text, query) {
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text.slice(0, 150) + "...";
  const start = Math.max(0, idx - 50);
  const end = Math.min(text.length, idx + 100);
  return "... " + text.slice(start, end)
    .replace(new RegExp(query, "ig"), (m) => `<mark>${m}</mark>`) + " ...";
}

function showResults(pages, query) {
  results.innerHTML = "";
  const matches = findMatches(pages, query);
  if (matches.length === 0) {
    results.innerHTML = "<li>No matches found.</li>";
  } else {
    matches.slice(0, 20).forEach(p => {
      const li = document.createElement("li");
      const snippet = highlightSnippet(p.content, query);
      li.innerHTML = `
        <strong>${p.title}</strong><br>
        <a href="${p.url}" target="_blank">${p.url}</a><br>
        <small>${new Date(p.timestamp).toLocaleString()}</small>
        <p style="font-size:12px;color:#444;">${snippet}</p>
      `;
      results.appendChild(li);
    });
  }
}

search.addEventListener("input", e => {
  const query = e.target.value.trim();
  if (!query) return results.innerHTML = "";
  chrome.storage.local.get(["pages"], (res) => {
    showResults(res.pages || [], query);
  });
});
