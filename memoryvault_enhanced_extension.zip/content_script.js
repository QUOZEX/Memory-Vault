function extractReadableText() {
  const bodyText = document.body ? document.body.innerText : "";
  const metaDesc = document.querySelector('meta[name="description"]')?.content || "";
  const title = document.title || "";
  const combined = `${title}\n${metaDesc}\n${bodyText}`;
  // Limit to 200k chars to avoid storage issues
  return combined.substring(0, 200000);
}

chrome.runtime.sendMessage({
  type: "SAVE_PAGE",
  data: {
    title: document.title || "(untitled)",
    url: location.href,
    content: extractReadableText()
  }
});
