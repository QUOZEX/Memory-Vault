chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SAVE_PAGE") {
    chrome.storage.local.get(["pages"], (res) => {
      const pages = res.pages || [];
      const existingIndex = pages.findIndex(p => p.url === msg.data.url);
      if (existingIndex >= 0) pages.splice(existingIndex, 1);
      pages.unshift({ ...msg.data, timestamp: Date.now() });
      if (pages.length > 300) pages.pop(); // store last 300 pages
      chrome.storage.local.set({ pages });
    });
  }
});
